BreakTheSpell local package created. Run deploy_pr_instructions.sh after editing REPO if needed.
